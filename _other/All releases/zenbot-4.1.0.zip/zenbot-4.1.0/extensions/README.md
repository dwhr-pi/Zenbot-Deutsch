# zenbot extensions

To support various exchanges, strategies or notifiers, zenbot "extensions" can be made.
This is a directory with a `_codemap.js` at root, which zenbot will scan and add to the codebase.

You may have to `npm install` in the extension directory, and/or copy and configure `conf-sample.js` to `conf.js` for it to work.

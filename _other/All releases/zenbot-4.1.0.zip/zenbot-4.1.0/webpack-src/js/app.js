// Import Bootstrap
import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'counterup/jquery.counterup.js';
import 'waypoints/lib/jquery.waypoints.min.js';
import '../../templates/dashboard_assets/js/custom.js';
import '../../templates/dashboard_assets/js/jquery.slimscroll.js';
import '../../templates/dashboard_assets/css/style.css';
import '../../templates/dashboard_assets/css/spinners.css';
import '../../templates/dashboard_assets/css/animate.css';
import '../../templates/dashboard_assets/css/colors/default.css';

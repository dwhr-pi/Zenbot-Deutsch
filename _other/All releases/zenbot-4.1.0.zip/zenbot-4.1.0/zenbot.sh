#!/bin/bash
env node zenbot.js $@

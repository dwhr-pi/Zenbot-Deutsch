module.exports = {
  _ns: 'zenbot',

  'output.api': require('./api')
}

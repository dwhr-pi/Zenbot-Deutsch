# Scripts
In the scripts folder are a number of helper scripts. This is the corresponding documentation so far, with more information on each set of scripts:

* [auto_backtester](auto_backtester.md) *not done yet, contributions welcome*
* [genetic_algo](genetic_algo.md) *not done yet, contributions welcome*
* [Genetic Backtester](genetic_backtester.md)


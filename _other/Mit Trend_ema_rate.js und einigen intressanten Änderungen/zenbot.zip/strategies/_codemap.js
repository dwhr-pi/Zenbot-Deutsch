module.exports = {
  _ns: 'zenbot',
  _folder: 'strategies',

  'trend_ema_rate': require('./trend_ema_rate'),

  'list[]': '#strategies.trend_ema_rate'
}
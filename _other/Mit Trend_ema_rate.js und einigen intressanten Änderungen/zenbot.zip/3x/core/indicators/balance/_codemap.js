module.exports = {
  _ns: 'zenbrain',
  'reporter_cols.balance': require('./reporter_col')
}
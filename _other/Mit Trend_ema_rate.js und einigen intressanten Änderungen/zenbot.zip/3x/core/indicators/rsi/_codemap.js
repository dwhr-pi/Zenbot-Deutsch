module.exports = {
  _ns: 'zenbrain',
  'reporter_cols.rsi': require('./reporter_col')
}
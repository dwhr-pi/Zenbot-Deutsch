module.exports = {
  _ns: 'zenbrain',
  'reporter_cols.num_trades': require('./reporter_col')
}
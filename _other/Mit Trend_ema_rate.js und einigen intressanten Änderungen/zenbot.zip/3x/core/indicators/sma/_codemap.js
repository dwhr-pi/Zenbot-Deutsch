module.exports = {
  _ns: 'zenbrain',
  'reporter_cols.sma': require('./reporter_col'),
  'tick_reducers[10]': require('./tick_reducer')
}
#!/bin/sh

./zenbot launch map --backfill run --config config_eth_btc.js --rs eth_btc

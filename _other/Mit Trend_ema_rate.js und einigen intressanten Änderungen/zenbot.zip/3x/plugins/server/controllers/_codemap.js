module.exports = {
  _ns: 'motley',
  'controllers[]': [
    require('./data'),
    require('./home')
  ]
}
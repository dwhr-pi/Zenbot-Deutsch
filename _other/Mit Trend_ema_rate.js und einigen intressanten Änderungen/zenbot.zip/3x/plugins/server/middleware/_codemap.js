module.exports = {
  _ns: 'motley',
  'middleware[]': require('./vars')
}
https://www.bitstamp.net/api/v2/transactions/btcusd/
https://www.bitstamp.net/api/

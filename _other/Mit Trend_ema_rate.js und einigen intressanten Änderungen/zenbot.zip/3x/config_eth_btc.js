var c = module.exports = require('./config')

c.assets = [
  "ETH"
]
c.currencies = [
  "BTC"
]

// selector for indicators, trading, etc
c.default_selector = "gdax.ETH-BTC"

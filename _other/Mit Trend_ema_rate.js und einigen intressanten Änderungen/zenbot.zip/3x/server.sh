#!/bin/sh

./zenbot launch server --config config.js

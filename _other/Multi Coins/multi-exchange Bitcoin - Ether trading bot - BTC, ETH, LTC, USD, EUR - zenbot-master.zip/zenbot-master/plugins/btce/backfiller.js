https://btc-e.com/api/3/docs#trades
https://btc-e.com/api/3/trades/btc_usd
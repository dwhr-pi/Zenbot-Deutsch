module.exports = function container (get, set, clear) {
  return null
}
module.exports = {
  _ns: 'zenbot',
  _maps: [
    require('./core/_codemap'),
    require('./plugins/_codemap'),
    require('./utils/_codemap')
  ]
}
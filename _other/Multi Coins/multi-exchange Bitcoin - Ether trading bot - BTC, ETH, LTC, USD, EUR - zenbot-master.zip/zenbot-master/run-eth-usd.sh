#!/bin/sh

./zenbot launch map --backfill run --config config_eth_usd.js --rs eth_usd

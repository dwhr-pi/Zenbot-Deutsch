#!/bin/sh

./zenbot launch map --backfill run --config config_btc_usd.js --rs btc_usd

var c = module.exports = require('./config')

c.assets = [
  "BTC"
]
c.currencies = [
  "USD",
  "USDT",
  "BTC"
]

// default selector for indicators, etc
c.default_selector = "gdax.BTC-USD"

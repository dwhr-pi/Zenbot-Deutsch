module.exports = {
  _ns: 'zenbrain',
  'reporter_cols.tick_id': require('./reporter_col')
}
module.exports = {
  _ns: 'zenbrain',
  'reporter_cols.timestamp': require('./reporter_col')
}
module.exports = {
  _ns: 'zenbrain',
  'reporter_cols.price': require('./reporter_col')
}
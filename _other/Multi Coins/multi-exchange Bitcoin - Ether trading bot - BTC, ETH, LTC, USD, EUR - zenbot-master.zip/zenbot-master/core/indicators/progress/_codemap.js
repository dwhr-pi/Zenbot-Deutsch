module.exports = {
  _ns: 'zenbrain',
  'reporter_cols.progress': require('./reporter_col')
}
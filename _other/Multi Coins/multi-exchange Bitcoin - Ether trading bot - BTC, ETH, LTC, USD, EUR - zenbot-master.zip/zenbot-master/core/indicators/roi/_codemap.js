module.exports = {
  _ns: 'zenbrain',
  'reporter_cols.roi': require('./reporter_col')
}
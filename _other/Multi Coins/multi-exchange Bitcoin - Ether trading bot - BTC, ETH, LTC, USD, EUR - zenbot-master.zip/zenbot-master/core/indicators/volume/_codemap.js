module.exports = {
  _ns: 'zenbrain',
  'reporter_cols.volume': require('./reporter_col')
}
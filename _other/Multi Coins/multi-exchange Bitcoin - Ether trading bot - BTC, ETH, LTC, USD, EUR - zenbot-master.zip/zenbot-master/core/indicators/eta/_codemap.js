module.exports = {
  _ns: 'zenbrain',
  'reporter_cols.eta': require('./reporter_col')
}
module.exports = {
  _ns: 'zenbrain',
  'reporter_cols.ansi_graph': require('./reporter_col')
}
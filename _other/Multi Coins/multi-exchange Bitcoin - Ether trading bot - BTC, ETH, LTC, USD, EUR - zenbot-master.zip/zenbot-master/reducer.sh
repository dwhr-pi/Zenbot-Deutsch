#!/bin/sh

./zenbot launch reduce --config config.js
